import { createApp } from 'vue'
import { createI18n } from 'vue-i18n'
import App from './App.vue'


const messages = {
  en: _ezMessages? _ezMessages : {} // eslint-disable-line
}

const i18n = createI18n({
    // something vue-i18n options here ...
    //locale: 'en',
    messages
  })
const app = createApp(App)


var UNITS = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
var STEP = 1024;
function formatSize(value, power) {
    return (value / Math.pow(STEP, power)).toFixed(2) + UNITS[power];
}

app.config.globalProperties.$filters = {
  fileSize(value) {
    value = parseFloat(value, 10);
        for (var i = 0; i < UNITS.length; i++) {
            if (value < Math.pow(STEP, i)) {
                if (UNITS[i - 1]) {
                    return formatSize(value, i - 1);
                }
                return value + UNITS[i];
            }
        }
        return formatSize(value, i - 1);
  }
}
app.use(i18n)
app.mount('#app')
