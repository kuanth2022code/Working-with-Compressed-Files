// Mish mash of common functions
import saveAs from 'file-saver'
import filesize from 'filesize'

export function getTruncName(filename, size) {
    // return filename.length;
    var fl = filename.length;
    if (fl < size) {
      return filename;
    } else {
      return "..." + filename.substring(fl-size);
    }
}
export function canPreview(filename) {
    let previewExts = ['JPG', 'JPEG', 'GIF', 'BMP', 'WEBP', 'PNG','SVG', 'ICO',
                        'MP3','WAV','OGG','WAV', 'MID', 
                        'PDF',
                        'MP4','OGV','MKV','MOV','WEBM',
                        'VUE', 'INF','HTML','JS','TXT', 'MD', 'SH', 'CSS', 'JAVA', 'XML', 'PROPERTIES', 'CONFIG', 'RB', 'JSON', 'LOG', 'JSP', 'RB', 'INI', 'LUA', 'CPP', 'H', 'PLM', 'RB','YML', 'CMD', 'CONF','LICENSE', 'MF' ,'NFO'];
    if (filename.indexOf('.') < 0) {
      return true;
    }
    if (filename.indexOf('.') == 0) { // These are the unix hidden files that start with . They aren't usually binary
      return true;
    }
    let extension = filename.split('.').pop().toUpperCase();    
    return (previewExts.indexOf(extension) !== -1);
}

export async function CreateDirectories(root_directory, file_path) {
    const path = file_path.split('/');
    const file_name = path.pop();
    let dir = root_directory;
    for (const component of path) {
        dir = 'getDirectory' in dir ? await dir.getDirectory(component, {create: true}) : await dir.getDirectoryHandle(component, {create: true});
    }
    return [dir, file_name];
  }

export function checkPasswordError(e) {
    console.log('e', e);
    if (e.message && e.message.indexOf('passphrase') > -1) {              
        return true;        
      } else if (e.message && e.message.indexOf('Password') > -1) {              
        return true;
      } else if (e.message && e.message.indexOf('Invalid pasword') > -1) {              
        return true;
      } else if (e.message && e.message.indexOf('Wrong password') > -1) {              
        return true;
      } else if (e.message && e.message.indexOf('Archive header or data are damaged') > -1) {   // When entering incorrect password for -some- rar files           
        return true;
      } else if (e.message && e.message.indexOf('Check password') > -1) {              
        return true;
      }
      //console.log('checkPasswordError',e);
    return false;
}

export function getPasswordAttempt(e) {  
  if (e.message && e.message.indexOf('Attempt=') > -1) {
    let attemptNo = e.message.split('=')[1];
    return parseInt(attemptNo);
  }
  return -1;
}


export function createFileListItem(fullpath, isDirectory, size) {    
  const directory = fullpath.split("/").slice(0,-1).join("/");
  const filename = fullpath.split('/').pop();
  const ext = filename.split('.').pop();  
  const sizeLabel = filesize(size);
    return {
        directory,
        filename, 
        fullpath,
        ext, 
        isDirectory, 
        size,
        sizeLabel,     
        canPreview: canPreview(filename), 
        truncName: getTruncName(fullpath, 100), 
        truncNameSM: getTruncName(fullpath, 70)
    };
}

export async function saveFile(blob, filename) {  
  if (window.showSaveFilePicker) {
      const handle = await window.showSaveFilePicker({
        suggestedName: filename      
      });
    const writable = await handle.createWritable();
    await writable.write(blob);
    await writable.close();
  } else {
    saveAs(blob, filename);
  }  
}

export function gaEvent(label, description) {  
  ga('send', 'event', label, description); // eslint-disable-line
}

export function gaException(description) {  
  ga('send', 'exception', {exDescription: description}); // eslint-disable-line
}

export function gaScreen(screen) {  
  ga('send', 'screenview', {screenName: screen, appName: 'ezyZip'}); // eslint-disable-line
}

export function safeFilename(fullpath) {
  return fullpath.replaceAll('*','-').replaceAll('~','-').replaceAll(':', '-');
}

export function isSafeFile(fullpath) {
    const filename = fullpath.split('/').pop();
    const ext = filename.split('.').pop();
    return !(fullpath.indexOf('desktop.ini') > -1 || fullpath.indexOf('Thumbs.db') > -1 || ext.indexOf('lnk') > 1);
}

// Just a way to pause things. Using it mainly when I want the UI to catch up a bit.
export async function pause(time) {
  return new Promise(function (resolve) {
    setTimeout(function () {
      resolve("anything");
    }, time);
  });  
}

export function Utf8ArrayToStr(array) {
  var out, i, len, c;
  var char2, char3;

  out = "";
  len = array.length;
  i = 0;
  while(i < len) {
  c = array[i++];
  switch(c >> 4)
  { 
    case 0: case 1: case 2: case 3: case 4: case 5: case 6: case 7:
      // 0xxxxxxx
      out += String.fromCharCode(c);
      break;
    case 12: case 13:
      // 110x xxxx   10xx xxxx
      char2 = array[i++];
      out += String.fromCharCode(((c & 0x1F) << 6) | (char2 & 0x3F));
      break;
    case 14:
      // 1110 xxxx  10xx xxxx  10xx xxxx
      char2 = array[i++];
      char3 = array[i++];
      out += String.fromCharCode(((c & 0x0F) << 12) |
                     ((char2 & 0x3F) << 6) |
                     ((char3 & 0x3F) << 0));
      break;
  }
  }

  return out;
}

export function utf8Decode(str) {
  return utf8.decode(str); // eslint-disable-line
}