
export default class DropboxService {
  // Code from https://github.com/dropbox/dropbox-sdk-js/tree/master/examples/javascript
   ACCESS_TOKEN = null;
   dbx = null;
   language;  
  
  constructor() {
    this.language = window._ezMessages.language; // FIX: This is quite hacky...
    
  }
  
  async uploadFile(filename, file) { 

      // TODO: Add support for files over 150mb
      //       See https://github.com/dropbox/dropbox-sdk-js/blob/main/examples/javascript/upload/index.html
      
      if (!this.isAuthenticated()) {
        console.log('dropbox authenticate');
        this.authenticate();
      }
      if (this.dbx) {
      
        // TODO: Don't think the error handling is working too well.. e.g. when you remove the 'autorename' bit...
        if (filename.charAt(0) != '/') {
          filename = '/' + filename;
        }
        try {
          //await this.dbx.filesUpload({path: filename, contents: file, autorename: true});
          await this.dbx.filesUpload({path: filename, contents: file, autorename: true});
                            
        } catch (err) {          
          
          if(err.error.error_summary.indexOf('expired') > -1) {
            this.ACCESS_TOKEN = null;
            localStorage.removeItem('dbx_access_token');
          } else {
            throw err;
          }   
        }
        /*
        this.dbx.filesUpload({path: filename, contents: file, autorename: true}) // eslint-disable-line
                            .then(successFn)
                            .catch(err => {
                                
                                if(err.error.error_summary.indexOf('expired') > -1) {
                                  this.ACCESS_TOKEN = null;
                                  localStorage.removeItem('dbx_access_token');
                                } else {
                                  throw err;
                                }

                                //errorFn();
                            });
                            */

      } else {
        console.log('NO DBX');
      }
      
      /*
      if (!this.dbx) {
        // TODO: 
        // 1. Check locaStorage for access token
        // 2. If not there, then send them to auth link in an iframe
        //    2a. Need to upload ezyZip         
        this.ACCESS_TOKEN = localStorage.getItem('dbx_access_token');
        console.log(this.ACCESS_TOKEN);
        if (!this.ACCESS_TOKEN) {
          //TODO: Open iframe iauth
          console.log('TODO: language code');          
          //let popupUrl = 'http://localhost:8080/dropbox-auth-finish-en.html';
          let popupUrl = 'http://localhost:8080/dropbox-auth/en';

          this.popupCenter(popupUrl, 'dpxAuth', 600, 500);
          
          //localStorage.setItem('dbx_access_token','EagVKOi8IFkAAAAAAAAAAdG9nSz8sqrfMHEg0vwZTZbm2I4Wuqw3TLpz_udCQIMy');
        } else {
          console.log('init dbx');
          this.dbx = new Dropbox.Dropbox({ accessToken: this.ACCESS_TOKEN }); // eslint-disable-line
          this.dbx.filesUpload({path: '/ezyZip/' + filename, contents: file}) // eslint-disable-line
        }
        //this.ACCESS_TOKEN = 'sl.AxAh2WdINf0ZoBKWky70FWoZ_Jn3P5svQ-SPuAyCf3LZIWKBlAvrpFY4sl8blKdKoAMOT8wthuBJg_uMukMeQWB0jKFC5q62H9z8ruBA7i5gHsKgl1oIgpJiQt0CnHHMGDKPLVs';
        //
      } else {
        console.log('access token is', this.ACCESS_TOKEN);
        this.dbx.filesUpload({path: '/ezyZip/' + filename, contents: file}) // eslint-disable-line
      }
      */      
  }

  isAuthenticated() {
    if (!this.dbx) {
      
      this.ACCESS_TOKEN = localStorage.getItem('dbx_access_token');
      if (this.ACCESS_TOKEN ) {
        this.dbx = new Dropbox.Dropbox({ accessToken: this.ACCESS_TOKEN }); // eslint-disable-line
        return true;
      } else {
        return false;
      }            
    } else {
      
      return true;
    }
  }

  authenticate() {
    if (!this.isAuthenticated()) {
      if (!this.ACCESS_TOKEN) {
        
        let popupUrl = 'https://www.ezyzip.com/dropbox-auth/' + this.language;
        console.log('popupUrl', popupUrl);
        this.popupCenter(popupUrl, 'dbxAuth', 600, 500);
      } else {
        console.log('init dbx');
        
        this.dbx = new Dropbox.Dropbox({ accessToken: this.ACCESS_TOKEN }); // eslint-disable-line
      }
    }      
  }

  popupCenter(url, title, w, h) {
    // Fixes dual-screen position                             Most browsers      Firefox
    const dualScreenLeft = window.screenLeft !==  undefined ? window.screenLeft : window.screenX;
    const dualScreenTop = window.screenTop !==  undefined   ? window.screenTop  : window.screenY;

    const width = window.innerWidth ? window.innerWidth : document.documentElement.clientWidth ? document.documentElement.clientWidth : screen.width;
    const height = window.innerHeight ? window.innerHeight : document.documentElement.clientHeight ? document.documentElement.clientHeight : screen.height;

    const systemZoom = width / window.screen.availWidth;
    const left = (width - w) / 2 / systemZoom + dualScreenLeft
    const top = (height - h) / 2 / systemZoom + dualScreenTop
    const newWindow = window.open(url, title, 
      `
      scrollbars=yes,
      width=${w / systemZoom}, 
      height=${h / systemZoom}, 
      top=${top}, 
      left=${left}
      `
    )

    if (window.focus) newWindow.focus();
}

  
}