//import _RARService  from './_RARService'
//import _LibArchiveService  from './_LibArchiveService' 
import DropboxService from './DropboxService' 
import {  gaException } from './Utils' 
//import * as zip from 'zip-js-webpack';

export default class _7ZConvertService {
    targetExtension;
    worker;
    convertedFile;
    fileList;
    totalFileCount;
    fileListError;
    _extractor;
    conversionRequired;
    archiveFile;
    archiveFileName;
    password;    
    _progressFn;
    
    constructor(archiveFile, targetExtension) {
        this.archiveFile = archiveFile;
        this.archiveFileName = archiveFile.name;
        this.targetExtension = targetExtension;
        let isTar = false;
        ['tar.gz', 'tgz', 'tar.bz2', 'tbz2','tbz', 'tar.xz', 'txz', 'tar.lz', 'tlz', 'tar.z' ].forEach(ext => {            
            if (this.archiveFileName.toLowerCase().indexOf(ext) > -1) {
                isTar = true;
            }
        })
        this.worker = new Worker('/assets/szw-19092022/c.js');
        this.worker.onmessage = msg => {
                
            switch (msg.data.type) {
                case 'fileList': {
                    this.fileList = msg.data.fileList;
                    this.encrypted = msg.data.encrypted;                                          
                    break;
                }
                case 'fileCount': {
                    // Sometimes encrypted files have encrypted file list too, so need to get file count again...
                    this.totalFileCount = msg.data.fileCount;
                    break;
                }
                case 'fileListError': {
                    //console.log(msg.data.error);
                    gaException('worker-fileListError|' + this.archiveFileName + '|' + JSON.stringify(msg.data.error));
                    this.fileListError = msg.data.error;                    
                    break;
                }
                case 'convertComplete': {
                    //console.log('convertDone', msg.data);
                    this.convertedFile = msg.data.file;
                    break;
                }
                case 'convertFileError': {
                    //console.log('convertDone', msg.data);

                    
                    gaException('worker-conversionError|' + this.archiveFileName + '|' + JSON.stringify(msg.data.error));
                    this.conversionError = msg.data.error;
                                        
                    break;
                }
                case 'conversionUpdate': {
                    //console.log('convertUpdate', msg.data);                                       
                    let currentFile = msg.data.file;
                    let fileCounter = msg.data.fileNo;                      
                    this._progressFn({currentFile, progress: fileCounter === 0? 0 : (fileCounter/this.totalFileCount)*95}); 
                    break;
                }
            }
            this.processing = false;            
        };

        this.processing = true;
        this.worker.postMessage({
            method: 'setArchiveFile',
            archiveFile,
            isTar,
            filter: '',
            targetExtension
        });      
    }

    isEncrypted() {
        const checkEncrypted = (resolve, reject) => {  
            setTimeout(() => {                
                if(this.fileList) {                    
                    this.totalFileCount = this.fileList.size;
                    resolve(this.encrypted);
                } else if (this.fileListError) {                    
                    reject(this.fileListError);
                } else {
                    checkEncrypted(resolve, reject); // check again after a second...
                }
            }, 100);                
       }
                  
        return new Promise((resolve, reject) => {
            return checkEncrypted(resolve, reject);
        });         
        
    }

    getConvertedFile() {
        return this.convertedFile;
    }

    setPassword(password) {        
        this.password = password;
        this.isEncrypted(); // Need to run this so it'll attempt to get fileCOunt again...
    }
    
    /*
    await(time) {
        return new Promise(function (resolve) {
          setTimeout(function () {
            resolve("anything");
          }, time);
        });
      }
      */

    // This needs to return a converted type!
    convert(level, progressUpdateFn) {         
        const checkIsConverted = (resolve, reject) => {  
            setTimeout(() => {      
                
                if(this.convertedFile) {
                    resolve(this.convertedFile);
                } else if (this.conversionError) {                         
                    reject(this.conversionError);
                } else {
                    checkIsConverted(resolve, reject); // check again after a second...
                }
            }, 500);                
       }
        this._progressFn = progressUpdateFn;
        
        this.worker.postMessage({
            method: 'convertFile',
            level,
            password: this.password,
            targetExtension: this.targetExtension            
        });

        return new Promise((resolve, reject) => {
            return checkIsConverted(resolve, reject);
        });               
    }
            

    async saveFileToDropbox() {        
        if(!this.dbxService) {
            this.dbxService = new DropboxService();
        }
        return this.dbxService.uploadFile('ezyZip.' + this.targetExtension, this.convertedFile);
    }
}