//import _RARService  from './_RARService'

//import _ZIPConvertService from './_ZIPConvertService' 
import _7ZConvertService from './_7ZConvertService' 


export default class ConvertService {
    converter;
    
    constructor(archiveFile, targetExtension) {
        /*
        let use7ZConverter = false;
        const ext = archiveFile.name.split('.').pop().toLowerCase();
        ['arj', 'msi', 'sfx', 'cpio', 'rpm', 'elf', 'egg', 'whl', 'wim'].forEach(e => {            
            if (ext == e) {
                use7ZConverter = true;
            }            
        })
        */
        this.converter = new _7ZConvertService(archiveFile, targetExtension);
        /*
        if (targetExtension == 'zip' && !use7ZConverter) {
            // this.converter = new _ZIPConvertService(archiveFile, targetExtension);
            this.converter = new _7ZConvertService(archiveFile, targetExtension);
        } else {
            this.converter = new _7ZConvertService(archiveFile, targetExtension);
        } 
        */                          
    }

    async isEncrypted() {        
        return this.converter.isEncrypted();
    }

    getConvertedFile() {        
        return this.converter.getConvertedFile();
    }

    setPassword(password) {
        this.converter.setPassword(password);
    }    
    
    async convert(level, progressUpdateFn) {
         return this.converter.convert(level, progressUpdateFn);        
    }

    async saveFileToDropbox() {        
        return this.converter.saveFileToDropbox();
    }
}