<template>

  <div
    style="position:relative;"
    :class="{'show-drag-container': showDrag}"
    @dragover="dragover" 
    @dragleave="dragleave" 
    @drop="drop"
  >
    <div :class="{'show-drag': showDrag,  'hide-drag': !showDrag}" style="background:#fff;opacity:0.5;box-sizing:border-box;border:5px solid #888;z-index:111;position:absolute;height:100%;width:100%;top:0;text-align:center;font-size:50px;">
        <span style="display:inline-block;height:100%;vertical-align:middle"></span>
        <i style="color:#888;vertical-align:middle;margin-top:-10px" class="fas fa-file-upload"></i>
    </div>
    <div>
      
          <Convert :drop-files="dropFiles" 
              :accepted-extensions="$t('page.acceptedExtension')"   
              :target-extension="$t('CONVERT.targetExtension')"
              />  
    
            
    </div>
  </div>
  
    
  
  <!--   
    <CompressImages :drop-files="dropFiles" :accepted-extensions="$t('page.acceptedExtension')"  />
    
    <Extract v-if="$t('CONVERT.toExtension') != 'CONVERT.toExtension'" :drop-files="dropFiles" 
              :accepted-extensions="$t('page.acceptedExtension')"
              :extension-filter="$t('CONVERT.toExtension')"  
    />  

    <NewArchive />

    <CompressImages :drop-files="dropFiles" :accepted-extensions="$t('page.acceptedExtension')"  />          

    <ZipFiles :drop-files="dropFiles"  />


    <ZipFolder  />  

    <Convert :drop-files="dropFiles" 
              :accepted-extensions="$t('page.acceptedExtension')"   
              :target-extension="$t('CONVERT.targetExtension')"
              />    
    
    
    
    <Extract v-if="$t('CONVERT.toExtension') == 'CONVERT.toExtension'" :drop-files="dropFiles" 
              :accepted-extensions="$t('page.acceptedExtension')"                
    />
    
    <Extract v-if="$t('CONVERT.toExtension') != 'CONVERT.toExtension'" :drop-files="dropFiles" 
              :accepted-extensions="$t('page.acceptedExtension')"
              :extension-filter="$t('CONVERT.toExtension')"  
    />
    

    <Convert :drop-files="dropFiles" 
              :accepted-extensions="$t('page.acceptedExtension')"   
              :target-extension="$t('CONVERT.targetExtension')"
              />
    
    <ZipFiles :drop-files="dropFiles"  />          
    <ZipFolder  />   
    
    
  -->
</template>

<script>
import Convert from './components/Convert.vue'
//import CompressImages from './components/CompressImages.vue'
//import Extract from './components/Extract.vue'
//import ZipFolder from './components/ZipFolder.vue'
//import ZipFiles from './components/ZipFiles.vue'
//import NewArchive from './components/NewArchive.vue'
import { gaEvent } from './services/Utils'

export default {
  name: 'App',
  components: {    
    Convert
    //Extract,    
    //ZipFolder,
    //ZipFiles
    //CompressImages
    //NewArchive
  },
  data() {
      return {
        showDrag: false,
        dropFiles: {}
      }
  },
  methods: {    
    dragover: function(event) {
      event.preventDefault();
      // Add some visual fluff to show the user can drop its files
      this.showDrag = true;
    },
    dragleave: function(event) {            
      event.preventDefault();      
      setTimeout(() => this.showDrag = false, 2000); // hacky way to prevent dropzone from flashing....      
    },
    drop: function(event) {
      event.preventDefault();
      this.dropFiles = {files: event.dataTransfer.files};
      this.showDrag = false;
      gaEvent('file-drop', window.location.pathname); 
    }
  }
}
</script>

<style>




#app {  
  margin-top: 60px;
}
[v-cloak] { 
  display:none; 
}
/*
a.btn-primary {
  background:#00c1fd !important
}
.dropdown-menu>li>a.bold {
  font-weight:bold !important
}
*/
.show-drag {
  display:block;
}
.hide-drag {
  display:none;
}
.show-drag-container {
  overflow:hidden;
}
</style>
