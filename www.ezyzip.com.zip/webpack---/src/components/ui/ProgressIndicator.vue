<template>
    <div>
        <h3 style="margin-top:0">{{ label }}<img class="loading-svg" src="https://www.ezyzip.com/assets/images/loading.svg" alt="uploading"  ></h3>        
        <div style="font-size:12px">{{progress.currentFile }}</div>  
        <div style="margin-top:" class="progress">                            
              <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" v-bind:style="{ width: progress.progress + '%' }" ></div>
        </div>
    </div>
</template>
<script>
export default {
  name: 'ProgressIndicator',
  props: {
    label: String,
    progress: Object
  }
  }
</script>