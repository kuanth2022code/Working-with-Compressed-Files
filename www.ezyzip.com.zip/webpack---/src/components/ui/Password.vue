<template>
    <div class="form-group" >
              

              <div v-if="error" class="alert alert-dismissible alert-danger">
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                <strong><i class="fas fa-exclamation-triangle"></i></strong> {{ $t("generic.password-error") }}
              </div>



              <input :placeholder="$t('generic.enter-password')" v-on:keydown.enter="setPassword" v-model="password" autocomplete="off" class="form-control form-control-lg" type="password"  >
              <button style="margin-top:20px" v-on:click="setPassword" type="button"  :disabled="!password"  class="btn pull-left btn-lg btn-primary  " >{{ $t("generic.set-password") }}</button>
              
            </div>
</template>
<script>
export default {
  name: 'Password',
  props: {
      error: Boolean
  },
  data() {
    return {   
        password: null
    }
  },
  methods: {
      setPassword: function() {
          this.$emit('set-password', this.password);
      }
  }
  }
</script>