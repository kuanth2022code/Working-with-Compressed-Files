<template>
  <div>
        
        
        <div v-if="downloadingFile">            
            <h3>{{ $t("generic.file-chooser-fetching") }}<img src="https://www.ezyzip.com/assets/images/loading.svg" alt="uploading" style="height:24px"  ></h3>
            <div style="margin-top:20px" class="progress">                
                <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" v-bind:style="{ width: downloadProgress + '%' }" ></div>
            </div>            
        </div>

        <div v-if="error"  class="alert alert-dismissible alert-danger">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <p><i class="fas fa-exclamation-triangle"></i>&nbsp;&nbsp;<span>{{ $t("generic.file-chooser-error") }}</span></p>
        </div>
        
        <div v-if="!downloadingFile">           
          
                <div v-if="isAdd" class="btn-group select-btn-group">                        
                      <label v-if="isMultiple" class="add-btn-label btn btn-sm btn-primary" for="extractMultipleFiles">{{ addLabel? addLabel : $t("generic.add-file-btn")  }}</label>                                         
                      <label v-if="isFolder" class="add-btn-label btn btn-sm btn-primary" for="extractFolder">{{ addLabel? addLabel : $t("generic.add-file-btn")  }} </label>                
                      <label v-if="!isFolder && !isMultiple" class="add-btn-label btn-sm btn btn-primary" for="extractFile">{{ addLabel? addLabel : $t("generic.add-file-btn")  }}   </label>                
                      
                      <button v-on:click="selectFromDropbox" @mouseover="changeAddLabel($t('generic.add-from-dropbox'))"  @mouseleave="changeAddLabel($t('generic.add-file-btn'))" type="button" class="btn btn-sm btn-primary"><i class="fab fa-dropbox" ></i></button>
                </div>
                <div v-if="!isAdd" class="btn-group select-btn-group">                        
                      
                      <label v-if="isMultiple" class="select-btn-label btn btn-lg btn-primary" for="extractMultipleFiles" v-html="selectLabel? selectLabel : $t('generic.select-file-btn') "></label>                                         
                      <label v-if="isFolder" class="select-btn-label btn btn-lg btn-primary" for="extractFolder" v-html="selectLabel? selectLabel : $t('generic.select-file-btn') "> </label>                
                      <label v-if="!isFolder && !isMultiple" class="select-btn-label btn btn-lg btn-primary" for="extractFile" v-html="selectLabel? selectLabel : $t('generic.select-file-btn') "></label>                

                      <button v-on:click="selectFromDropbox" @mouseover="changeLabel($t('generic.select-from-dropbox'))"  @mouseleave="changeLabel($t('generic.select-file-btn'))"  type="button" class="btn btn-lg btn-primary"><i class="fab fa-dropbox" ></i></button>                                            
                </div>
                
                <!-- The label triggers the input, so hiding the input -->            
                <input v-if="isMultiple"  multiple name="extractMultipleFiles" id="extractMultipleFiles" style="display:none" v-on:change="changeMultipleFiles" autocomplete="off" class="form-control-file  input-lg" type="file" :accept=" acceptedExtensions" >
                <input v-if="isFolder" webkitdirectory directory  name="extractFolder" id="extractFolder" style="display:none" v-on:change="changeFolder" autocomplete="off" class="form-control-file  input-lg" type="file" >                
                <input  v-if="!isFolder && !isMultiple" name="extractFile" id="extractFile" style="display:none" v-on:change="changeFile" autocomplete="off" class="form-control-file  input-lg" type="file" :accept=" acceptedExtensions" >
        </div>
    </div>
</template>

<script>
import axios from 'axios';
import { gaEvent } from '../../services/Utils'


// TODO: Add google picker.. 
// https://developers.google.com/picker/docs#example
// https://github.com/kieusonlam/vue-gpicker
export default {    
  name: 'FileChooser',  
  props: {    
    isFolder: Boolean,
    isMultiple: Boolean,    
    isAdd: Boolean,
    //multipleFiles: Boolean,
    fileChosen: Function,
    acceptedExtensions: String
  },
  components: {
    
  },
  mounted() {
    let dropBox = document.createElement("script");
    dropBox.setAttribute(
      "src",
      "https://www.dropbox.com/static/api/2/dropins.js"
    );
    dropBox.setAttribute("id", "dropboxjs");
    dropBox.setAttribute("data-app-key", "31v3oyb0l3pi5tx");
    document.head.appendChild(dropBox);
  },
  data() {
    return {        
        fileName: null,
        fileSize: 0,
        //file: null,
        dropboxFile: null,
        downloadProgress: 0,
        downloadingFile: false,
        error: false,
        selectLabel: '',
        addLabel: ''
    }
  },
  methods: {
        changeLabel: function(label) {
          this.selectLabel = label;
        },
        changeAddLabel: function(label) {
          this.addLabel = label;
        },
        setFileName: function(dropboxFile) {
            this.fileName = dropboxFile.name;
            this.fileSize = dropboxFile.bytes;
            this.dropboxFile = dropboxFile;
        },
        selectFromDropbox: function() {          
          if (this.isFolder) {
            this.chooseDropboxFolder();            
          } else if (this.isMultiple) {            
            this.chooseMultipleDropboxFiles();
          } else {            
            this.chooseDropboxFile();
          }
        },
        showDetails: function(files) {
            console.log(files);
        },        
        chooseDropboxFolder: function() {
          //let _this = this;
          //console.log('chooseDropboxFolder');
          
          let options = {
              // Required. Called when a user selects an item in the Chooser.
              
              success: async files => {                
                //_this.setFileName(files[0]); 
                //console.log('selected folder', files);
                // _this.downloadDropboxFile(files[0].link);
                if (files.length && files[0].isDir) {
                  let returnFile = {
                    'type': 'dropbox-folder',
                    'folder': files[0].name,
                    'url': files[0].link.replace('dl=0', 'dl=1')
                  }
                  this.$emit('folder-chosen', returnFile);
                }                
              },
              // Optional. Called when the user closes the dialog without selecting a file
              // and does not include any parameters.
              cancel: function() {},
              linkType: "preview",
              
              folderselect: true, // or true
              sizeLimit: 102400000 // or any positive number
            };
            
          Dropbox.choose(options);   // eslint-disable-line
          gaEvent('choose-dropbox-folder', window.location.pathname); 
        },
        chooseMultipleDropboxFiles: function() {
          let _this = this;
          let extensions = this.acceptedExtensions.replace(/\s/g, '').split(','); // TODO: make it work with multiple
          
          
          //let allowedExtensions = [this.$props.allowedExtensions]; // TODO: make it work with multiple
          let options = {
              // Required. Called when a user selects an item in the Chooser.
              
              success: async files => {                
                //_this.setFileName(files[0]); 
                //console.log('selected files', files);
                 //_this.downloadDropboxFile(files[0].link);
                this.downloadingFile = true;
                let fileList = [];
                for (let f of files) {
                  //console.log('...f', f);
                  let downloadedFile = await _this.downloadFile(f.link);
                  console.log('downloadedFile', downloadedFile);
                  let file = new File([downloadedFile.data], f.name);
                  fileList.push(file);
                  //console.log('...f..', downloadedFile);
                }


                
                let returnFiles = {
                  'type': 'multiple-files',
                  'files': fileList
                }
                
                this.$emit('multiple-files-chosen', returnFiles);
                this.downloadingFile = false;

              },
              // Optional. Called when the user closes the dialog without selecting a file
              // and does not include any parameters.
              cancel: function() {},
              linkType: "direct",
              extensions: extensions,
              folderselect: false, // or true
              multiselect: true,
              sizeLimit: 102400000 // or any positive number
            };
            
          Dropbox.choose(options);   // eslint-disable-line
          gaEvent('choose-dropbox-file', window.location.pathname);
        },
        chooseDropboxFile: function() {
          let _this = this;          
          let extensions = this.acceptedExtensions.replace(/\s/g, '').split(','); // TODO: make it work with multiple          
          //let allowedExtensions = ['.zip'];
          let options = {
              // Required. Called when a user selects an item in the Chooser.
              
              success: async files => {                
                //_this.setFileName(files[0]); 
                console.log('selected files', files);
                 // THIS ONE WORKS BELOW
                 //_this.downloadDropboxFile(files[0].name, files[0].link);
                  let downloadedFile = await _this.downloadFile(files[0].link);
                  let file = new File([downloadedFile.data], files[0].name);

                  this.downloadingFile = false;                                
                  let returnFile = {
                    'type': 'file',
                    'file': file
                  }                
                  this.$emit('file-chosen', returnFile);
              },
              // Optional. Called when the user closes the dialog without selecting a file
              // and does not include any parameters.
              cancel: function() {},
              linkType: "direct",
              extensions: extensions,
              folderselect: false, // or true
              sizeLimit: 102400000 // or any positive number
            };
            
          Dropbox.choose(options);   // eslint-disable-line
          gaEvent('choose-dropbox-file', window.location.pathname); 
        },
        downloadFile: async function(fileUrl) {
            
            //console.log('downloadFileUrl=', fileUrl);
            const downloadedFile = await axios.get(fileUrl, {responseType: 'blob'});
            return downloadedFile;
        },        
        changeFile: function(e) {
            let returnFile = {
              'type': 'file',
              'file': e.currentTarget.files[0]
            }                        
            this.$emit('file-chosen', returnFile);
        },
        changeMultipleFiles: function(e) {
            let returnFiles = {
              'type': 'multiple-files',
              'files': e.currentTarget.files
            }
            //console.log(returnFiles);
            this.$emit('multiple-files-chosen', returnFiles);
        },
        changeFolder: function(e) {
          let returnFiles = {
              'type': 'folder',
              'files': e.currentTarget.files
            }
          this.$emit('folder-chosen', returnFiles);
        }
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
