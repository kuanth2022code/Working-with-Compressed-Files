<template>
    
<div id="app-body-container" >
      
      
    <div  >
          <form role="form" >
            
              <!--  
                <div class="form-group" v-if="!loading && !passwordRequired">
                    <label for="extractFile">{{ $t("CONVERT.select-file") }}</label>
                    <input v-on:change="changeFile" autocomplete="off" class="form-control-file input-lg" type="file" :accept="$t('page.acceptedExtension')" >
                </div>
              -->
              <!-- Hacky way to trigger computed dropfilesUpdate property to ensure the drag/drop works correctly -->
             <!-- TODO: One day find a better solution --> 
            <div style="display:none">{{dropFilesUpdate}}</div>
            
              <FileChooser v-if="!archiveFilename && !processing"                           
                           @file-chosen="setFile"
                           :accepted-extensions="acceptedExtensions"
              />
              <Password v-if="passwordRequired" :error="passwordError" @set-password="setPassword" />
              
              <h3 style="margin-top:0;margin-bottom:20px" v-if="!passwordRequired && archiveFilename && !converted && !loading && !processing"> {{ $t("CONVERT.selected-file") }} <b>{{ archiveFilename }}</b></h3>
              
              <ProgressIndicator  v-if="loading && !converted" :progress="progress" :label="$t('generic.converting')" />
              
               <div class="form-group" v-if="processing" >
                <h3 style="margin-top:0">{{ $t("ZIP.processing") }}<img class="loading-svg" src="https://www.ezyzip.com/assets/images/loading.svg" alt="uploading"  ></h3>                
              </div>
                  
              <div class="form-group " v-if="converted && !uploading">
                <h3 style="margin-top:0">{{ $t("CONVERT.file-conversion-complete") }}</h3>
                {{ $t("CONVERT.file-conversion-save") }}
                
                <!--
                <a style="margin-top:20px;margin-right:5px" :href="$t('page.pageRoute')" class="btn btn-primary pull-left btn-lg" >{{ $t("generic.convert-other-file") }}</a>
                -->
              </div>
              <div class="form-group" v-if="converted && uploading" >
                <h3 style="margin-top:0">{{ $t("generic.uploading-file")}} <img class="loading-svg" src="https://www.ezyzip.com/assets/images/loading.svg" alt="uploading"  ></h3>                
              </div> 



              <div class="form-group large-label" v-if="errorConverting">
                  {{ $t("generic.error-converting") }}<br>
                <a style="margin-top:20px;margin-right:5px" :href="$t('page.pageRoute')" class="btn btn-primary float-start btn-lg" >{{ $t("generic.convert-other-file") }}</a>
              </div>
 
              <div v-if="!passwordRequired && !converted && !processing"> 
                      <div  class="form-group" v-if="archiveFilename && !loading && !passwordRequired">
                          
                          <a :href="$t('page.pageRoute')"  class=" btn btn-default float-start btn-lg" style="margin-right:5px">{{ $t("generic.reset") }}</a>
                          
                          <button v-on:click="convertArchive" type="button" :disabled="loading"  class="btn float-start btn-lg btn-primary  d-md-none  " >{{ loading? $t("ZIP.processing") : $t("CONVERT.convert-to-zip") }}</button>
                          
                          <div class="btn-group" role="group">
                                <div class="btn-group zip-button d-none d-md-inline " v-if="!loading">
                                    <a  v-on:click="convertArchive" href="#" rel="nofollow"  class="btn btn-primary btn-lg" v-html="$t('CONVERT.convert-to-zip')"></a>
                                    
                                    
                                    <button id="compressionDrop" type="button" class="btn btn-lg btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
                                    
                                    <div class="dropdown-menu bg-primary" aria-labelledby="compressionDrop">            
                                      <a class="dropdown-item" @click="setCompression($event, 0)" v-bind:style="{ fontWeight: compressionLevel === 0? '900' : '100' }" href="#">{{ $t("generic.no-compression") }}</a>
                                      <a class="dropdown-item" @click="setCompression($event, 4)" v-bind:style="{ fontWeight: compressionLevel === 4? '900' : '100' }" href="#" >{{ $t("generic.medium-compression") }}</a>
                                      <a class="dropdown-item" @click="setCompression($event, 9)" v-bind:style="{ fontWeight: compressionLevel === 9? '900' : '100' }" href="#" >{{ $t("generic.max-compression") }}</a>
                                    </div>
                                  </div>
                            </div>
                      </div>
              </div>
              <div style="margin-top:40px" v-if="converted && !uploading" class="form-group">                
                <a style="margin-right:5px" :href="$t('page.pageRoute')" class="btn btn-default btn-lg float-start ng-fadeInLeft " >{{ $t("generic.reset")}}</a>
                <button type="button" class="hidden-lg  d-md-none btn btn-success btn-lg float-start ng-fadeInLeft " v-on:click="saveFile">{{ $t("ZIP.save-zip") }}</button>
                <div class="btn-group d-none d-md-inline ng-fadeInLeft ">
                    <a v-on:click="saveConvertedFile" href="#" class="btn btn-lg btn-success">{{ $t("CONVERT.save-converted-file") }}</a>
                    
                    <button id="saveDrop" type="button" class="btn btn-lg btn-success dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
                    <div class="dropdown-menu bg-success" aria-labelledby="saveDrop">                                
                        <a class="dropdown-item" v-on:click="saveToDropbox" rel="nofollow" href="#"><i class="fab fa-dropbox"></i>&nbsp;Dropbox</a>                                       
                    </div>
                </div>
              </div>
              
          </form>
    </div>
      
</div>

</template>




<script>

import FileChooser from './ui/FileChooser.vue'
import ProgressIndicator from './ui/ProgressIndicator.vue'
import Password from './ui/Password.vue'
import ConvertService from '../services/ConvertService'
//import _7ZConvertService from '../services/_7ZConvertService'
import { gaEvent, gaException, getPasswordAttempt, checkPasswordError, saveFile } from '../services/Utils'


export default {
  name: 'Convert',
  computed: {
      dropFilesUpdate() {        
        //console.log('dropFilesUpdate')
        // TODO: Maybe fix this hacky solution one day...?
        if (this.dropFiles && this.dropFiles.files) {
          if (this.lastDrop != this.dropFiles) {            
            this.setFile({file: this.dropFiles.files[0]});            
          }          
        }        
        return this.dropFiles;
      }
    },
  props: {
    dropFiles: Object,
    acceptedExtensions: String,
    targetExtension: String
  },
  components: {
    FileChooser,
    ProgressIndicator,
    Password
  },
  data() {
       return {
        archiveFilename: null,
        convertService: null,        
        progress: {currentFile: '', progress: 0},
        processing: false,
        loading: false,
        converted: false,        
        convertedFile: null,        
        compressionLevel: 9,
        errorConverting: false,        
        errorConversionMsg: '',
        fileExtension: null,        
        passwordRequired: false,
        passwordAttempt: 0,
        passwordError: false,           
        uploading: false
      };
     }, 
    methods: {      
      
      setCompression: function(e, level) {
          this.compressionLevel = level;
          e.preventDefault();
          gaEvent('convert2-zipper-level', level); 
      },      
      convertArchive: async function() {
        
        try {          
          this.loading = true;                
          await this.convertService.convert(this.compressionLevel,
                                    (progress) => {this.progress = progress;}, this.password).then(function() {                                      
                                    });          
          
          this.loading = false;
          this.converted = true;
          gaEvent('convert2-convert-archive', window.location.pathname);
        } catch (e) {
          console.log('ConvertE',e);
          if (checkPasswordError(e)) {        
                  //console.log(e.message);
                  let attempt = getPasswordAttempt(e);

                  if (attempt > 0) {
                    if(attempt > this.passwordAttempt) {
                      this.passwordRequired = true;                                                   
                      this.passwordError = true;
                      this.loading = false;  
                      this.passwordAttempt = attempt;
                    } else {
                      console.log('Received stale exception. Ignore...');
                    }
                  } else {
                    this.passwordRequired = true;                                                   
                    this.passwordError = true;
                    this.loading = false;
                  }
                  
                  gaEvent('convert2-incorrect-password', window.location.pathname); 
                  
          } else {
            alert('ERROR: Could not convert file');                   
            console.log(e);
            this.loading = false;                
            gaException('convert2-convert-archive-error|'+ this.archiveFilename +'|'+ JSON.stringify(e.message));
          }
        }        
      },
      setPassword: function(password) {
        this.passwordRequired = false;
        this.convertService.setPassword(password);
      },
      saveConvertedFile: function() {
          try {
            let _ext = this.targetExtension? this.targetExtension : "zip";
            saveFile(this.convertService.getConvertedFile(), "ezyZip." + _ext);            
          } catch(e) {
            alert('ERROR: Could not save file');                   
            console.log(e);            
            gaException('convert2-save-error|' + JSON.stringify(e.message));
          }          
      },
      saveToDropbox: async function() {
          try {
            this.uploading = true;
            await this.convertService.saveFileToDropbox();
            this.uploading = false;
            gaEvent('convert2-save-dropbox', window.location.pathname);
          } catch(e) {
            this.uploading = false;
            alert('Error saving to Dropbox');
            gaException('convert2-save-dropbox-error|' + JSON.stringify(e.message));
          }
      },            
      setFile: async function(fileChooser) {
            
        this.fileExtension = fileChooser.file.name.split('.').pop().toLowerCase();
        if(this.acceptedExtensions.indexOf(this.fileExtension) > -1) {
          try {
          this.processing = true;               
          this.archiveFilename = fileChooser.file.name;
          this.convertService = new ConvertService(fileChooser.file, this.targetExtension);          
          this.passwordRequired = await this.convertService.isEncrypted();
          this.processing = false;
          } catch(e) {
            this.processing = false;    
            let filename = this.archiveFilename;
            this.archiveFilename = null;
            console.log(e);
            gaException('convert2-set-file-error|' + filename+ '|' + JSON.stringify(e.message));
            window.setTimeout(() => { // Slight delay so UI updates correctly...
              alert('Error loading file!');                                      
              
            },50);             
          }
          
        } else {
          console.log('invalid file extension');
        }
      }
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
